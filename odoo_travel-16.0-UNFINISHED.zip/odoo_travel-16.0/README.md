# Travel Agency Module for Odoo 16.0

This module was originally developed by OpenJAF for Odoo 8.0. It has been updated and is now maintained by **Vincent Luba** of **Business Solutions For Africa**.

## Original Author
- **OpenJAF** - [http://www.openjaf.com](http://www.openjaf.com)

## Maintainer
- **Business Solutions For Africa** - [https://www.biz-4-africa.com/odoo-travel](https://www.biz-4-africa.com/odoo-travel)

==============

OpenERP solution to manage Sales, Products, Prices and Accounting in Travel Agencies

License
-------
Odoo Proprietary License v1.0 (OPL-1)
(https://www.odoo.com/documentation/16.0/legal/licenses.html#odoo-apps)
