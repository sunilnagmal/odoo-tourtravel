from odoo import _, api, fields, models

class Pax(models.Model):
    _inherit = "travel_core.pax"
