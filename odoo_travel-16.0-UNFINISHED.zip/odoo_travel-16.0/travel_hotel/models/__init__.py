from . import product_template
from . import sale_order_line
from . import travel_hotel_allotment
from . import product_product
from . import sale
from . import supplierinfo
from . import account_move
from . import account_partner_ledger
from . import travel_line_details

# from . import pax
# TODO: Add pax model
