## Migration Summary
**Module:** [module_name]
**From Version:** [source_version]
**To Version:** [target_version]
**Related Issue:** #[issue_number]

### Technical Changes
- [] Updated manifest version
- [] Adapted models to new API
- [] Fixed view architectures
- [] Updated demo data

### Test Results
```bash
odoo-bin -d test_db -u module_name --test-enable --stop-after-init
```
Tests executed: [list_tests_run]
Passed: X/X
Warnings: [list_warnings]
Errors: [list_errors]

### Checklist
-[] Backward compatibility verified
-[] Documentation updated (README/CHANGELOG)
-[] Dependencies checked
-[] Code reviewed

### Notes
[any_additional_notes]

/label ~migration ~18.0
/assign @username1 @username2
/reviewer @team-name
